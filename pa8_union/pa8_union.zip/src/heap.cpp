#include "../include/heap.hpp"
#include <iostream>

Heap::Heap(int maxsize) {
    this->tamanho = 0;
    this->data = new s_edge[maxsize];

};

Heap::~Heap() {
    delete[] data;
};

void Heap::Inserir(s_edge vertice) {

    data[tamanho] = vertice;
    int i = tamanho;
    int p = GetAncestral(i);

    while(data[i].custo < data[p].custo) {

        s_edge tmp;

        tmp = data[i];
        data[i] = data[p]; 
        data[p] = tmp;

        i = p;
        p = GetAncestral(i);
    }


    tamanho++;

};

s_edge Heap::Remover() {
    
    
    if(!Vazio()) {
        s_edge x = data[0];
        data[0] = data[tamanho-1];
        tamanho--;

        int i = 0;
        int s = data[GetSucessorEsq(i)].custo < data[GetSucessorDir(i)].custo ? GetSucessorEsq(i) : GetSucessorDir(i);


        while(data[i].custo > data[s].custo && s <= tamanho) {
                
                //std::cout << "Trocando os n " << i << " " << s << std::endl;
                s_edge tmp;

                tmp = data[i];
                data[i] = data[s]; 
                data[s] = tmp;

                i = s;
                s = data[GetSucessorEsq(i)].custo < data[GetSucessorDir(i)].custo ? GetSucessorEsq(i) : GetSucessorDir(i);
        }


    
        return x;
    }

    s_edge x = data[0];
    return x;
    

};

//Retorna true caso o heap esteja vazio, false caso contrário.

bool Heap::Vazio() {
    return this->tamanho == 0;
};


int Heap::GetAncestral(int posicao) {

    return (posicao-1)/2;

};

int Heap::GetSucessorEsq(int posicao) {

    return 2 * posicao + 1;

};

int Heap::GetSucessorDir(int posicao) {

    return 2 * posicao + 2;

};
