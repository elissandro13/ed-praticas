#include "../include/unionFind.hpp"
#include "../include/heap.hpp"



UnionFind::UnionFind(int quantidade_subconjuntos) {

    this->subconjuntos = new Subconjunto[quantidade_subconjuntos];
    this->tamanho = 0;

    for (int i = 0; i < quantidade_subconjuntos; i++)
    {
        subconjuntos[i].representante = i;
        subconjuntos[i].rank = -1;
    }
    
};

UnionFind::~UnionFind() {

    delete[] subconjuntos;

};

void UnionFind::Make(int x) {



};

int UnionFind::Find(int x) {
    
    return subconjuntos[x].representante;

};

void UnionFind::Union(int x, int y) {

    if(x < y) {
        if(subconjuntos[y].representante == y) {
            subconjuntos[y].representante = x;
                return;
        }

        return Union(x, subconjuntos[y].representante); 

    }
        
    else {
        if(subconjuntos[x].representante == x) {
            subconjuntos[y].representante = y;
                
        }

        return Union(y, subconjuntos[x].representante);

    }
            

    

    
};
